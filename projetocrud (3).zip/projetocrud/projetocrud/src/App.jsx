import './App.css';
import Create from './components/create'
import Read from './components/read'

  function App() {
    return (
        <div className="main">
          <h2 className="main-header">Formulário de Cadastro</h2>
        <div>
          <Create/> <br /> <br />
          <Read/>
        </div>
        </div>
    )
  }
export default App;