import React from 'react'
import { Button, Checkbox, Icon, Table } from 'semantic-ui-react'

export default function Read(){
    return(
<div>
  <Table>
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell />
        <Table.HeaderCell>Nome</Table.HeaderCell>
        <Table.HeaderCell>Sobrenome</Table.HeaderCell>
        <Table.HeaderCell>Checkbox</Table.HeaderCell>
        <Table.HeaderCell>Ação</Table.HeaderCell>
      </Table.Row>
    </Table.Header>

    <Table.Body>
      <Table.Row>
        <Table.Cell collapsing>
          <Checkbox slider />
        </Table.Cell>
        <Table.Cell>John Wick</Table.Cell>
        <Table.Cell>September 14, 2013</Table.Cell>
        <Table.Cell>godsniper@yahoo.com</Table.Cell>
        <Table.Cell>No</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell collapsing>
          <Checkbox slider />
        </Table.Cell>
        <Table.Cell>Tomb Rider</Table.Cell>
        <Table.Cell>January 11, 2014</Table.Cell>
        <Table.Cell>tombinha123@yahoo.com</Table.Cell>
        <Table.Cell>Yes</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell collapsing>
          <Checkbox slider />
        </Table.Cell>
        <Table.Cell>Jill Lewis</Table.Cell>
        <Table.Cell>May 11, 2014</Table.Cell>
        <Table.Cell>jilsewris22@yahoo.com</Table.Cell>
        <Table.Cell>Yes</Table.Cell>
      </Table.Row>
    </Table.Body>

    <Table.Footer fullWidth>
      <Table.Row>
        <Table.HeaderCell />
        <Table.HeaderCell colSpan='4'>
          <Button
            floated='right'
            icon
            labelPosition='left'
            primary
            size='small'
          >
            <Icon name='user' /> Adicionar usuário
          </Button>
          <Button size='small'>Aprovar</Button>
          <Button disabled size='small'>
            Aprovar todos
          </Button>
        </Table.HeaderCell>
      </Table.Row>
    </Table.Footer>
  </Table>
  </div>
)

}