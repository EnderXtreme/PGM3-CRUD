import axios from 'axios';
import React, { useState, useEffect } from 'react'
import { Button, Checkbox, Icon, Table, TableRow } from 'semantic-ui-react'

export default function Read(){
  const[APIData,setAPIData] = useState([]);
  useEffect(() => {
    axios.get('https://63780b0a0992902a2515b79f.mockapi.io/usuario')
        .then((responde) => {
          console.log(responde.data)
          setAPIData(responde.data);
        })
  },   []);

    const setData = (data) => {
      let { id, firstName, lastName, checkbox} = data;
      localStorage.setItem('ID',id);
      localStorage.setItem('Primeiro Nome',firstName);
      localStorage.setItem('Sobrenome',lastName);
      localStorage.setItem('Chekbox',checkbox);

    const onDelete = (id) => {
      if (window.confirm("Confirmar Exclusão?")){
        axios.delete(`https://63780b0a0992902a2515b79f.mockapi.io/usuario/${id}`);
    }

    }



    return(
        <div>
          <Table singleLine>
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell>Nome</Table.HeaderCell>
                <Table.HeaderCell>Sobrenome</Table.HeaderCell>
                <Table.HeaderCell>Confirmação</Table.HeaderCell>
                <Table.HeaderCell>Ação</Table.HeaderCell>
                
              </Table.Row>
            </Table.Header>

            <Table.Body>
            {APIData.map((data) => {
              return(
                <Table.Row>
                  <Table.Cell>
                    {data.firstName}
                  </Table.Cell>
                  <Table.Cell>
                    {data.lastName}
                  </Table.Cell>
                  <Table.Cell>
                    {data.checkbox ?'confirmado': 'Nao confirmado'}
                  </Table.Cell>
                  <Table.Cell>
                    <Button onClick={() => onDelete (data.id)}>Remover</Button>
                  </Table.Cell>
                </Table.Row>
              )
            }
            )}
            </Table.Body>

            <Table.Footer fullWidth>
              <Table.Row>
                <Table.HeaderCell />
                <Table.HeaderCell colSpan='4'>
                  <Button
                    floated='right'
                    icon
                    labelPosition='left'
                    primary
                    size='small'
                  >
                    <Icon name='user' /> Adicionar usuário
                  </Button>
                  <Button size='small'>Aprovar</Button>
                  <Button disabled size='small'>
                    Aprovar todos
                  </Button>
                </Table.HeaderCell>
              </Table.Row>
            </Table.Footer>
          </Table>
          </div>
)
    }}